from flask import Flask, render_template, request, jsonify, session
import os
import random
import json
from datetime import datetime
import google.generativeai as genai

# === CONFIGURATION ===
FLASK_SECRET_KEY = 'af17f3241cc639962cae4ec159e660dd136d717ae46956d6af9e7afab33c8fef'
GEMINI_API_KEY = 'AIzaSyCZxnt_il55d8I9O7InZuQrZqi_gxIY8-U'

app = Flask(__name__, template_folder='template')
app.secret_key = FLASK_SECRET_KEY
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# === GEMINI SETUP ===
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)
    model = genai.GenerativeModel('gemini-2.0-flash')
else:
    print("Warning: GEMINI_API_KEY not set.")
    model = None

# === SESSION INIT ===
def init_session():
    session.setdefault('score', 0)
    session.setdefault('total_questions', 0)
    session.setdefault('history', [])
    session.setdefault('current_question', None)
    session.setdefault('used_questions', [])

# === QUESTION GENERATOR ===
def generate_question(difficulty):
    if not model:
        raise Exception("Gemini model not initialized.")

    prompt = f"""
    Generate a unique world geography multiple-choice question in JSON format only.
    Requirements:
    - Difficulty: {difficulty}
    - JSON format:
    {{
      "question": "Which country has the highest waterfall?",
      "options": ["Brazil", "Norway", "Venezuela", "Canada"],
      "correct_answer": "Venezuela",
      "hint": "It is home to Angel Falls.",
      "difficulty": "{difficulty}"
    }}
    IMPORTANT: Only output pure JSON with double quotes. Do NOT explain anything.
    """

    try:
        response = model.generate_content(prompt)
        response_text = response.text.strip()
    except Exception as e:
        print("Gemini API Error:", e)
        raise

    # Remove Markdown formatting if present
    if response_text.startswith('```json'):
        response_text = response_text[7:-3].strip()
    elif response_text.startswith('```'):
        response_text = response_text[3:-3].strip()

    try:
        question_data = json.loads(response_text)
    except json.JSONDecodeError as e:
        print("JSON decode error:", e)
        print("Raw response:", response_text)
        raise

    required_keys = ['question', 'options', 'correct_answer', 'hint', 'difficulty']
    if not all(key in question_data for key in required_keys):
        raise ValueError("Incomplete question format")

    if len(question_data['options']) != 4:
        raise ValueError("Question must have 4 options")

    # Fix mismatched correct_answer by matching string (case insensitive)
    correct = question_data['correct_answer'].strip().lower()
    matched = None
    for opt in question_data['options']:
        if opt.strip().lower() == correct:
            matched = opt
            break
    if not matched:
        print("Original Gemini response:", response_text)
        raise ValueError("Correct answer must match one of the options")
    question_data['correct_answer'] = matched

    if question_data['question'] in session['used_questions']:
        raise ValueError("Duplicate question generated")

    random.shuffle(question_data['options'])  # shuffle after validation

    return question_data

# === ROUTES ===
@app.route('/')
def home():
    session.clear()
    init_session()
    return render_template('index.html')

@app.route('/get_question', methods=['GET'])
def get_question():
    init_session()
    difficulty = 'easy'
    score = session.get('score', 0)
    if score >= 5:
        difficulty = 'hard'
    elif score >= 2:
        difficulty = 'medium'

    max_retries = 3
    for _ in range(max_retries):
        try:
            question_data = generate_question(difficulty)
            break
        except Exception as e:
            print(f"Question generation failed: {str(e)}")
            continue
    else:
        return jsonify({'error': 'Failed to generate question'}), 500

    session['used_questions'].append(question_data['question'])
    session['current_question'] = {
        **question_data,
        'timestamp': datetime.now().isoformat()
    }

    return jsonify({
        'question': question_data['question'],
        'options': question_data['options'],
        'hint': question_data['hint'],
        'difficulty': question_data['difficulty']
    })

@app.route('/check_answer', methods=['POST'])
def check_answer():
    init_session()
    data = request.get_json()
    if not data or 'answer' not in data:
        return jsonify({'error': 'Answer not provided'}), 400

    current_question = session.get('current_question')
    if not current_question:
        return jsonify({'error': 'No active question'}), 400

    user_answer = data['answer'].strip().lower()
    correct_answer = current_question['correct_answer'].strip().lower()
    is_correct = user_answer == correct_answer

    if is_correct:
        session['score'] += 1
    session['total_questions'] += 1

    session['history'].append({
        'question': current_question['question'],
        'user_answer': data['answer'],
        'correct_answer': current_question['correct_answer'],
        'is_correct': is_correct,
        'difficulty': current_question['difficulty'],
        'timestamp': current_question['timestamp']
    })

    return jsonify({
        'is_correct': is_correct,
        'correct_answer': current_question['correct_answer'],
        'score': session['score'],
        'total_questions': session['total_questions']
    })

@app.route('/get_history', methods=['GET'])
def get_history():
    init_session()
    return jsonify({
        'history': session.get('history', []),
        'score': session.get('score', 0),
        'total_questions': session.get('total_questions', 0)
    })

if __name__ == '__main__':
    app.run(debug=True)
